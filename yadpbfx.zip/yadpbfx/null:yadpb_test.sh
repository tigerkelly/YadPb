#!/usr/bin/bash

/usr/bin/yad --color --details=/etc/X11/rgb.txt --details=Hex --expand --response=0 --text-align=Fill --hscroll-policy=auto --vscroll-policy=auto 


package application;

public interface DialogInterface {
	public abstract void updateDialog();
	public abstract void saveDialog();
	public abstract void setData(String data);
}

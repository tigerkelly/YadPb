package application;

public enum WidgetType {

	BUTTON,
	CHECKBOX,
	TOGGLEBUTTON,
	TEXTFIELD,
	TEXTAREA,
	REGION;
}

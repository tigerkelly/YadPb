package application;

public interface RefreshScene {
	public abstract void refreshScene();
	public abstract void leaveScene();
	
	public abstract void clickIt(String text, WidgetType widgetType);
}

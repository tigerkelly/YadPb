package application;

import javafx.fxml.FXMLLoader;
import javafx.scene.Node;

public class SceneInfo {

	public FXMLLoader loader;
	public Node node;
	public Object controller;
	public String classType;
	public long startTime;
}
